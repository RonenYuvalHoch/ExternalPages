<?php
//phpinfo(); //i had to install some ssh dll in the php.ini in order for this to work
$xml_obj = simplexml_load_file('http://www.lotterymaster.com/lotteries-xml');
//print_r($xml_obj);
if (isset($_SERVER['HTTP_REFERER'])){
	$referer = $_SERVER['HTTP_REFERER'];
}else{
	$referer = '';
}

function debug1(){
	$placeholder = "<br>==========================<br>";
	$plains_array = Array('boolean','integer','double','string');
	$args = func_get_args();
	$btrace = debug_backtrace();
	if (is_bool($args[0])){
		$all = $args[0];
		unset($args[0]);
	} else
		$all = FALSE;

	if ($all==FALSE){
		$rbt = Array($btrace[1]);
	} else {
		$rbt=array_reverse($btrace);
	}
	foreach($rbt as $index=>$data){
		$tmp_args = Array();
		foreach ($data['args'] as $idx=>$arg){
			$atype = gettype($arg);
			if (in_array($atype,$plains_array)){
				$arg_text = $arg;
				if (is_string($arg)) $arg_text = '"'.$arg_text.'"';
				if (is_bool($arg)) $arg_text = ($arg?'TRUE':'FALSE');
			} else {
				$arg_text = $atype.'#'.count($arg);
			}
			$tmp_args[$idx] = $arg_text;
		}
		$args_string = implode(', ',$tmp_args);
		$stack[$index]=basename($data['file']).':'.$data['line'].' -- '.$data['function'].'('.$args_string.')';
	}
	echo '<pre>';
	echo "Trace:".$placeholder;
	print_r($stack);
	echo $placeholder.'Arguments'.$placeholder;
	print_r($args);
	die();
}

$Get2free = 'Get 2 free tickets for the next El Gordo De La Primitiva lottery';
$Wehavealready = 'We have already handed out over 55,000,000 in prizes';
$Leaveyourphone = 'Leave your phone number to get your FREE lottery ticket';
$Name = 'Name';
$Country = 'Country';
$Selectcountry = 'Select country';
$PhoneNumber = 'Phone Number';
$Official = 'Official';

if (isset($_REQUEST['language'])){
	switch ($_REQUEST['language']) {
		case 'en':
			$Get2free = 'Get 2 free tickets for the next El Gordo De La Primitiva lottery';
			$Wehavealready = 'We have already handed out over 55,000,000 in prizes';
			$Leaveyourphone = 'Leave your phone number to get your FREE lottery ticket';
			$Name = 'Name';
			$Country = 'Country';
			$Selectcountry = 'Select country';
			$PhoneNumber = 'Phone Number';
			$Official = 'Official';
		case 'fr':
		//debug1($_REQUEST['language']);
			$Get2free = 'frGet 2 free tickets for the next El Gordo De La Primitiva lottery';
			$Wehavealready = 'frWe have already handed out over 55,000,000 in prizes';
			$Leaveyourphone = 'frLeave your phone number to get your FREE lottery ticket';
			$Name = 'frName';
			$Country = 'frCountry';
			$Selectcountry = 'frSelect country';
			$PhoneNumber = 'frPhone Number';
			$Official = 'frOfficial';
	}
}

$PB_jackpot = 'Not published';
$SE_jackpot = 'Not published';
$EGP_jackpot = 'Not published';
$UNL_jackpot = 'Not published';
$LP_jackpot = 'Not published';
$EJ_jackpot = 'Not published';
$UEM_jackpot = 'Not published';
$EM_jackpot = 'Not published';
$MM_jackpot = 'Not published';
//$draw_path = 'superenalotto-lottery';
$draw_path = '';

foreach ($xml_obj->node as $k => $val) {
//debug1($val->LotteryID);
//$tit = trim($val->title);
	if (isset($val->Jackpot)){
		$jackpot = number_format(str_replace(' ','',$val->Jackpot));
	}
	switch ($val->LotteryID) {
		//case 'PowerBall':
		case '3':
			$PB = $k;
			if (isset($val->Jackpot)){
				$PB_jackpot = '$ ' . $jackpot;
			}else{
				$PB_jackpot = 'Not published';
			}
			break;
		//case 'SuperEnalotto':
		case '1':
			$SE = $k;
			if (isset($val->Jackpot)){
				$SE_jackpot = '&euro; ' . $jackpot;
			}else{
				$SE_jackpot = 'Not published';
			}
			break;
		//case 'El Gordo de la Primitiva':
		case '6':
			$EGP = $k;
			if (isset($val->Jackpot)){
				$EGP_jackpot = '&euro; ' . $jackpot;
			}else{
				$EGP_jackpot = 'Not published';
			}
			$draw_path = $val->Path;
			break;
		//case 'UK National Lotto':
		case '7':
			$UNL = $k;
			if (isset($val->Jackpot)){
				$UNL_jackpot = '&pound; ' . $jackpot;
			}else{
				$UNL_jackpot = 'Not published';
			}
			break;
		//case 'La Primitiva':
		case '5':
			$LP = $k;
			if (isset($val->Jackpot)){
				$LP_jackpot = '&euro; ' . $jackpot;
			}else{
				$LP_jackpot = 'Not published';
			}
			break;
		//case 'EuroJackpot':
		case '9':
			$EJ = $k;
			if (isset($val->Jackpot)){
				$EJ_jackpot = '&euro; ' . $jackpot;
			}else{
				$EJ_jackpot = 'Not published';
			}
			break;
		//case 'UK EuroMillions':
		case '18':
			$UEM = $k;
			if (isset($val->Jackpot)){
				$UEM_jackpot = '&pound; ' . $jackpot;
			}else{
				$UEM_jackpot = 'Not published';
			}
			break;
		//case 'Euro Millions':
		case '4':
			$EM = $k;
			if (isset($val->Jackpot)){
				$EM_jackpot = '&euro; ' . $jackpot;
			}else{
				$EM_jackpot = 'Not published';
			}
			break;
		//case 'Mega Millions':
		case '2':
			$MM = $k;
			if (isset($val->Jackpot)){
				$MM_jackpot = '$ ' . $jackpot;
			}else{
				$MM_jackpot = 'Not published';
			}
			break;
	}
}



?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<link rel="stylesheet" type="text/css" href="css/reset.css"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>

<title>Lottery</title>
<script>
function validateForm()
{
var x=document.forms["myF"]["name"].value;
if (x==null || x=="")
  {
  alert("Name must be filled out.");
  return false;
  }
if (x.length < 3)
  {
  alert("Name must have more than 2 chars.");
  return false;
  }
var x=document.forms["myF"]["Phone"].value;
if (x==null || x=="")
  {
  alert("Phone must be filled out.");
  return false;
  }
if (!isNumeric(x))
  {
  alert("Phone must be numeric.");
  return false;
  }
if (x.length < 5)
  {
  alert("Phone must have more than 4 digits.");
  return false;
  }
var x=document.forms["myF"]["country_id"].value;
if (x==null || x=="")
  {
  alert("Country must be filled out.");
  return false;
  }
  
}
function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}
</script>
</head>
<body>
<div class="container">
	<div class="wrap_all">
		<h1><?PHP print $Get2free; ?></h1>
		<h2 class="h2_El">El Gordo De La Primitiva</h2>
		<div class="wrap_price"> 
			<p><?php print $EGP_jackpot; ?></p>
			<span><?PHP print $Wehavealready; ?></span>
		</div>
		<div class="hold_form">
			<form name="myF" action="/free-lottery/loading.php" method="get" autocomplete="on" onsubmit="return validateForm();">
				<div class="form_details">
					<p><?PHP print $Leaveyourphone; ?></p>
					<div class="wrap_label">	
						<label><?PHP print $Name; ?></label>
						<input type="text" name="name">
						<label><?PHP print $Country; ?></label>
						<div class="selecthold">
							<select name="country_id" id="country_id" tabindex="1">
								<option value=""><?PHP print $Selectcountry; ?></option>
								<option value="USA">USA</option>
								<option value="Canada">Canada</option>
								<option value="France">France</option>
								<option value="Spain">Spain</option>
								<option value="Bulgaria">Bulgaria</option>
								<option value="Greece">Greece</option>
								<option value="Italy">Italy</option>
								<option value="Japan">Japan</option>
								<option value="China">China</option>
								<option value="Brazil">Brazil</option>
								<option value="South Africa">South Africa</option>
							</select>
						</div>
						<label><?PHP print $PhoneNumber; ?></label>
						<input name="Phone" autocomplete="on"><br>
					</div>
					<input id="submit" type="submit" value="GET YOUR FREE TICKET">
				</div>
						<input type="hidden" name="referer" value="<?PHP print $referer; ?>">
						<input type="hidden" name="popupate_webform" value="On">
						<input type="hidden" name="lotterymaster_dest" value="http://www.lotterymaster.com<?php print $draw_path; ?>">
			</form>
		</div>
		<div class="footer footerposition">
			<div class="footer_logo">
				<img src="images/el-condo.png" width="51" height="43" class="El_Condo" alt="EL GORDO"/>
				<p><?PHP print $Official; ?> Spanish Lottery<span>EL GORDO</span></p>
				<strong><?PHP print $EGP_jackpot;?></strong>
			</div>
			<div class="footer_logo">
				<img src="images/superenlotto.png" width="90" height="23" class="Super_Enalotto" alt="SUPERENALOTTO"/>
				<p><?PHP print $Official; ?> Italy Lottery<span>SUPERENALOTTO</span></p>
				<strong><?PHP print $SE_jackpot;?></strong>
			</div>
			<div class="footer_logo">
			<img src="images/national.png" width="37" height="37" class="blue_logo" alt="THE NATIONAL LOTTERY"/>
				<p><?PHP print $Official; ?> UK Lottery<span>THE NATIONAL LOTTERY</span></p>
				<strong><?PHP print $UNL_jackpot;?></strong>
			</div>
			<div class="footer_logo">
			<img src="images/euro.png" width="55" height="33" class="Edro_millions" alt="EURO MILLIONS"/>
				<p><?PHP print $Official; ?> Europe Lottery<span>EURO MILLIONS</span></p>
				<strong><?PHP print $EM_jackpot;?></strong>
			</div>
			<div class="footer_logo">
			<img src="images/mega_million.png" width="64" height="32" class="Mega_Million" alt="MEGA MILLIONS"/>
				<p><?PHP print $Official; ?> USA Lottery<span>MEGA MILLIONS</span></p>
				<strong><?PHP print $MM_jackpot;?></strong>
			</div>
			<div class="footer_logo">
				<img src="images/power.png" width="84" height="18" class="Power_Ball" alt="SUPERBALL"/>
				<p><?PHP print $Official; ?> USA Lottery<span>SUPERBALL</span></p>
				<strong><?PHP print $PB_jackpot;?></strong>
			</div>
			<div class="footer_logo footer_jumbo">
			<img src="images/jumbo.png" width="127" height="40" class="Jumbo_Lotto" alt="JUMBO LOTTO"/>
				<p><?PHP print $Official; ?> Japanese Lottery<span>JUMBO LOTTO</span></p>
				<strong><?PHP print $EGP_jackpot;?></strong>
			</div>
		</div>
	</div>
</div>
		<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
		<script type="text/javascript" src="js/jquery.selectbox-0.2.js"></script>
		<script type="text/javascript">
		$(function () {
			$("#country_id").selectbox();
		});
		</script>
</body>
</html>